from time import time
from random import randint

def rand_list(upper, lower, size):
    rnd_list = []
    for i in range(size):
        rnd_list.append(randint(lower, upper))
    return rnd_list



def bubble_sort(list):
    list_sorted = False
    while not list_sorted:
        for i in range(len(list)-1):
            if list[i] > list[i + 1]:
                temp_hold = list[i]
                list[i] = list[i + 1]
                list[i + 1] = temp_hold
                break
        else:
            list_sorted = True

    return list


def selection_sort(list):
    new_list = []
    while len(list) > 0:
        high = 0
        for number in list:
            if number > high:
                high = number

        new_list.append(high)
        list.remove(high)

    return new_list

"""

random_list = rand_list(100, 0, 1000)

time_0 = time()
# print(bubble_sort(random_list))
time_1 = time()
print('Bubble sort run time:', time_1-time_0)

time_0 = time()
print(selection_sort(random_list))
time_1 = time()
print('Selection sort run time:', time_1-time_0)

"""