print("Første for-løkke")
for x in range(1, 6):
    print (x)

print()
print("Første while-løkke")
x = 1
while x < 6:
    print (x)
    x += 1

print()
print("Andre for-løkke")
for x in range(15, 0, -1):
    print (x)

print()
print("Andre while-løkke")
x = 15
while x > 0:
    print (x)
    x -= 1
