def factorial_loop(n):
    svar = 1
    for i in range(1, n+1):
        svar *= i
    return svar

def nchoosek(n,k):
    return int(factorial_loop(n)/(factorial_loop(k)*factorial_loop(n-k)))

def Pascal(n):
    for i in range(0, n+1):
        for j in range(0, i+1):
            print(nchoosek(i, j), end=' ')
        print("")

print(Pascal(1000000))